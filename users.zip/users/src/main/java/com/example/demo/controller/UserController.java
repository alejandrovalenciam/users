package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.User;
import com.example.demo.service.UserServiceImpl;

@RestController
@RequestMapping("/users")
@CrossOrigin("*")
public class UserController {
	@Autowired
	UserServiceImpl userService;
	
	@GetMapping("")
	ResponseEntity<List<User>> getUsers(){
		return new ResponseEntity<>(userService.getUsers(), HttpStatus.OK);			
	}
	
	@GetMapping(path = "/{id}")
	public ResponseEntity<Optional<User>> getUserById(@PathVariable int id) {
		return new ResponseEntity<>(userService.getUserById(id), HttpStatus.OK);			
	}
	
	@PostMapping("/agregar")
	public ResponseEntity<User> addUser(@RequestBody User user) {
		return new ResponseEntity<>(userService.saveUser(user), HttpStatus.OK);
	}
	
	@PutMapping("/actualizar")
	public ResponseEntity<User> updateUser(@RequestBody User user) {
		return new ResponseEntity<>(userService.saveUser(user), HttpStatus.OK);
	}
	
	@DeleteMapping(path = "/eliminar/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable int id) {
		return new ResponseEntity<>(userService.deleteUser(id), HttpStatus.OK);
	}
}
