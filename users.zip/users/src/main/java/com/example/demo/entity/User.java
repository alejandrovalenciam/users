package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	//@Column(name = "name", nullable = false)
	private String name;
	
	//@Column(name = "lastname")
	private String lastname;
	
	//@Column(name = "city")
	private String city;
	
	//@Column(name = "email")
	private String email;
	
	//@Column(name = "password")
	private String password;
}
